﻿import grcwa
import numpy as np
import math


def test(person):
    return "What's up " + person;


def abc(a,b,c):
    k=np.sum(np.array([a+b+c,1,1])*3)
    return k


# n_m���� 3�� �޾ƾ� ��
# ��Ʈ�� index 1���� ���� // ���̽� 0���� ����

"""import module"""



def function_test(wavelength_reconstruction, wavelength_recording1, wavelength_recording2, wavelength_recording3,
                  T_or_R,
                  diff_order, n1, n2, n, nm1, nm2, nm3, thickness, shrinkageQ,
                  Exr, Eyr, Ezr, Exi, Eyi, Ezi, sam_x, sam_y, nn,
                  recon_x, recon_y, recon_z, grating_x, grating_y, grating_z):
    """define the unit"""
    # mm = 1e-03
    # um = 1e-06
    nm = 1e-09
    """Anonymous function"""
    Norm = lambda x: x / np.sqrt(sum(x * x))  # okay
    Abs_size = lambda x: np.sqrt(sum(x * x))  # okay
    # Refracted_angle = lambda n_inc, n_ref, theta_inc: np.arcsin(n_inc / n_ref * np.sin(np.deg2rad(theta_inc)))  # okay
    Sampling = lambda L, ds: np.arange(-L / 2, L / 2, ds)  # matlab -L/2:ds:L/2-ds 와는 조금 다름 큰문제는 없을듯?
    Divide = lambda x, y: np.array([x // y, x % y])  # 몫 나머지
    noused = np.array(
        [wavelength_recording2, wavelength_recording3, Exr, Eyr, Ezr, Exi, Eyi, Ezi, nm2, nm3, shrinkageQ])

    def lcm(a, b):
        return (a * b) // math.gcd(a, b)

    def LCM(A, r):
        Lcmx = int(lcm(int(round(A[0] * r, 3)), int(round(A[1] * r, 3))))
        Lcmx = np.array([lcm(int(round(A[2] * r, 3)), Lcmx) / r])
        return Lcmx

    def Rotation_z(angle, x, y):  # angle : radians x,y,z 좌표계에서 여러 벡터들을 회전하는걸로 생각
        x_prime = np.cos(angle) * x - np.sin(angle) * y
        y_prime = np.sin(angle) * x + np.cos(angle) * y
        if x == 0 and y == 0:
            x_prime = 0
            y_prime = 0
        return np.array([x_prime, y_prime])

    # Recording parameters 파장의 경우 레이저에서 많이 사용하는 473, 532, 633nm 기준으로 확인 할 것

    if grating_x == 0 and grating_y == 0:
        angle_beta = 0
    elif grating_x == 0 and grating_y / np.abs(grating_y) < 0:
        angle_beta = np.pi / 2
    elif grating_x == 0 and grating_y / np.abs(grating_y) > 0:
        angle_beta = -np.pi / 2
    else:
        angle_beta = np.arctan(-grating_y / grating_x)
    grating_xy_prime = Rotation_z(angle_beta, grating_x, grating_y)
    grating_vec_prime = np.array([grating_xy_prime[0], grating_xy_prime[1], grating_z])  # y성분 0이어야함
    K_vec = np.array([grating_vec_prime[0], grating_vec_prime[2]])  # 멀티 플렉싱에서 수정해줘야함 1*2 2*2 3*2 되게끔 일단 스킵
    if abs(grating_xy_prime[0]) < 0.00000001 or abs(grating_z) < 0.00000001:
        U_or_S = 1
    else:
        U_or_S = -1


    n_m_array = np.array([nm1, nm2, nm3])
    #n_m_array = np.array([nm1])
    wavelength_recording = np.array([wavelength_recording1, wavelength_recording2, wavelength_recording3])
    # wavelength_recording = np.array([wavelength_recording1])
    # wave_recor_signifi=3 #do not used
    delta_array = (wavelength_recording-wavelength_reconstruction)*(wavelength_recording-wavelength_reconstruction)
    if delta_array[0]-delta_array[1]>=0:
        if delta_array[1] - delta_array[2] >=0:
            recon_index = 2
        else:
            recon_index = 1
    else:
        if delta_array[0] - delta_array[2] >=0:
            recon_index = 2
        else:
            recon_index = 0
    K_geometry = K_vec * wavelength_recording[recon_index] / 2 / np.pi / n




    freq = 1 / wavelength_reconstruction


    # System parameters
    sampling_x = sam_x  # number of sampling with one period / unsl 인경우 이거 기준 계산
    sampling_z = sam_y  # number of sampling with one period

    # obj = np.array([obj_x,obj_y,obj_z])
    # ref = np.array([ref_x,ref_y,ref_z])
    play = np.array([recon_x, recon_y, recon_z])
    play_rot = Rotation_z(angle_beta, play[0], play[1])
    if play_rot[0] ==0 and play_rot[1] ==0:
        angle_delta = 0
    elif play_rot[0]==0 and play_rot[1]/np.abs(play_rot[1]) <0:
        angle_delta=np.pi/2
    elif play_rot[0]==0 and play_rot[1]/np.abs(play_rot[1]) >0:
        angle_delta = -np.pi / 2
    else:
        angle_delta = np.arctan(-play_rot[1] / play_rot[0])  # rotation angle about z-axis, see manual
    play_rot2 = Rotation_z(angle_delta, play_rot[0], play_rot[1])
    theta0 = np.arctan(play_rot2[0] / recon_z)  # + or -
    K = Abs_size(K_geometry)*2*np.pi*n/wavelength_recording
    # KK = np.array([])

    # for a in range(np.size(wavelength_recording)):
    #     KK=np.array([np.sqrt(np.sum(K[a-1,:])),KK])
        # KK = np.append(np.sqrt(np.sum(K[a, :])), KK)
    # K = KK
    Erxy_rot = Rotation_z(angle_beta, Exr, Eyr)
    Eixy_rot = Rotation_z(angle_beta, Exi, Eyi)
    Er = np.array([Erxy_rot[0], Erxy_rot[1], Ezr])
    Ei = np.array([Eixy_rot[0], Erxy_rot[1], Ezi])
    if Abs_size(Er) == 0 and Abs_size(Ei) ==0:
        Samp = 0.5
        Pamp = 0.5
        Sphase = 0
        Pphase = 0
    else:
        r = np.array([play_rot[0], play_rot[1], recon_z])
        z = np.array([0, 0, -1])
        if Abs_size(np.cross(r,z)) == 0:
            Sr = Er[0]
            Si = Ei[0]
            Pr = Er[1]
            Pi = Ei[1]
        else:
            S_direction = Norm(np.cross(r,z))
            P_direction = Norm(np.cross(r,S_direction))
            Sr = np.dot(Er, S_direction)
            Si = np.dot(Ei, S_direction)
            Pr = np.dot(Er, P_direction)
            Pi = np.dot(Ei, P_direction)
        Samp = np.sqrt(Sr*Sr + Si*Si)
        Pamp = np.sqrt(Pr*Pr + Pi*Pi)
        pol_size = np.sqrt(Samp*Samp+ Pamp*Pamp)
        Samp = Samp/pol_size
        Pamp = Pamp/pol_size
        if Sr ==0 and Si ==0:
            Sphase = 0
        elif Sr == 0 and Si/np.abs(Si)>0:
            Sphase = np.pi/2
        elif Sr == 0 and Si/np.abs(Si)<0:
            Sphase = -np.pi/2
        else:
            Sphase = np.arctan(Si/Sr)

        if Pr == 0 and Pi ==0:
            Pphase = 0
        elif Pr == 0 and Pi/np.abs(Pi)>0:
            Pphase = np.pi/2
        elif Pr == 0 and Pi/np.abs(Pi)<0:
            Pphase = -np.pi/2
        else:
            Pphase = np.arctan(Pi/Pr)

    planewave = {'p_amp': Pamp, 's_amp': Samp, 'p_phase': Pphase, 's_phase': Sphase}
    if Abs_size(K_vec) == 0:

        obj = grcwa.obj(nn, [1*nm, 0], [0, 1 * nm], freq, theta0, -angle_delta, verbose=0)
        obj.Add_LayerUniform(0, n1 * n1)
        obj.Add_LayerUniform(thickness, n * n)
        obj.Add_LayerUniform(0, n2 * n2)
        obj.Init_Setup()
        obj.MakeExcitationPlanewave(planewave['p_amp'], planewave['p_phase'], planewave['s_amp'],
                                    planewave['s_phase'], order=0)  # reference order??
        R, T = obj.RT_Solve(normalize=1, byorder=1)
        diffraction_order=0
    else:

        Lambda = 2 * np.pi / K
        if K_vec[1] == 0:
            theta_fringe =np.pi/2
        else:
            theta_fringe = np.arctan(K_vec[0] / K_vec[1])
        if theta_fringe ==0:
            sign_fringe = np.pi/2
        else:
            sign_fringe = theta_fringe / np.abs(theta_fringe)
        if U_or_S == 1:  # unslanted인 경우
            K_vec_recon = 2 * np.pi * n / wavelength_recording[recon_index] * Abs_size(K_geometry)
            Lambda_recon = 2 * np.pi / K_vec_recon
            s_size_array = Lambda
            Lcms = s_size_array
            A = np.abs(s_size_array)
            r = np.abs(1e09 * 100 * n * Abs_size(K_geometry))
            Lcms = LCM(A, r)
            Lcms = Lcms / (Lcms / (Lambda_recon))
            ds = Lcms / sampling_x
            s = Sampling(Lcms, ds)
            layer = np.array([])

            for b in range(np.size(wavelength_recording)):
                # layer = np.append(layer, [n_m * np.cos(2 * np.pi * ((s) / s_size_array[b]))])  # 나중에 if 처리 해야함
                layer = np.append([n_m_array[b] * np.cos(2 * np.pi * ((s + sign_fringe) / s_size_array[b]))],
                                  layer)  # 나중에 if 처리 해야함
                # layer = np.array([layer, [n_m * np.cos(2 * np.pi * (s + sign_fringe / s_size_array[0, b - 1]))]])
            layer2 = layer.reshape(np.size(wavelength_recording), sampling_x)
            layer3 = np.sum(layer2, axis=0)
            layer = layer3 + n
            # R_array = np.array([])
            # T_array = np.array([])
            if T_or_R == 1:
                # theta0 = Refracted_angle(n1, n, i * interval_angle + start_angle)
                obj = grcwa.obj(nn, [Lcms[0], 0], [0, 1 * nm], freq, theta0, -angle_delta, verbose=0)
                obj.Add_LayerUniform(0, n1 * n1)
                obj.Add_LayerGrid(thickness, sampling_x, 1)
                obj.Add_LayerUniform(0, n2 * n2)
                obj.Init_Setup()
                obj.GridLayer_geteps(layer * layer)
                obj.MakeExcitationPlanewave(planewave['p_amp'], planewave['p_phase'], planewave['s_amp'],
                                            planewave['s_phase'], order=0)  # reference order??
                R, T = obj.RT_Solve(normalize=1, byorder=1)

            else:  ###############################################################################################################################################
                dz = ds
                z = Sampling(thickness, dz)
                num_one_layer = np.size(s)
                num_total_layer = np.size(z)
                set_z = Divide(num_total_layer, num_one_layer)
                layer = []
                for b in range(np.size(wavelength_recording)):
                    layer = np.append(layer, [n_m_array[b] * np.cos(2 * np.pi * ((z) / s_size_array[b]))])  # 나중에 if 처리 해야함

                layer2 = layer.reshape(np.size(wavelength_recording), num_total_layer)
                layer3 = np.sum(layer2, axis=0)
                layer1 = layer3 + n

                # layer1 = n_m * np.cos(2 * np.pi * (z / Lcms))
                # layer1 = n + layer3

                # theta0 = np.deg2rad(i * interval_angle + start_angle)

                obj = grcwa.obj(nn, [1 * nm, 0], [0, 1 * nm], freq, theta0, -angle_delta, verbose=0)
                obj.Add_LayerUniform(0, n1 * n1)
                for ii in range(num_total_layer):
                    obj.Add_LayerUniform(dz, layer1[ii] * layer1[ii])
                obj.Add_LayerUniform(0, n * n)
                obj.Init_Setup()
                obj.MakeExcitationPlanewave(planewave['p_amp'], planewave['p_phase'], planewave['s_amp'],
                                            planewave['s_phase'], order=0)  # reference order??
                if A > Lambda_recon:
                    R, T = obj.RT_Solve(normalize=0, byorder=1)
                else:
                    R, T = obj.RT_Solve(normalize=1, byorder=1)



        else:  # slanted인 경우
            theta_fringe = np.arctan(K_vec[0] / K_vec[1])  # radians
            sign_fringe = theta_fringe / np.abs(theta_fringe)
            theta_fringe = np.abs(theta_fringe)
            theta_K = np.arctan(K_vec[1] / K_vec[0])
            x_size_array = Lambda / np.sin(theta_fringe)
            z_size_array = Lambda / np.cos(theta_fringe)
            A = np.abs(x_size_array)
            r = np.abs(1e09 * 100 * np.sin(theta_fringe) * n * Abs_size(K_geometry))
            Lcmx = LCM(A, r)

            K_vec_recon = 2 * np.pi * n / wavelength_recording[recon_index] * Abs_size(K_geometry)
            Lambda_recon = 2 * np.pi / K_vec_recon

            Lcmxx = Lcmx / (Lcmx / (Lambda_recon / np.sin(theta_fringe)))
            dxx = Lcmxx / sampling_x
            xx = Sampling(Lcmxx, dxx)

            dx = Lcmx / sampling_x
            x = Sampling(Lcmx, dx)

            AA = abs(z_size_array)
            rr = np.abs(1e09 * 100 * np.cos(theta_fringe) * n * Abs_size(K_geometry))
            Lcmz = LCM(AA, rr)
            Lcmzz = Lcmz / (Lcmz / (Lambda_recon / np.cos(theta_fringe)))
            if Lcmz > thickness:
                dz = Lcmzz / sampling_z
                z = Sampling(thickness, dz)
            else:
                dz = Lcmz / sampling_z
                z = Sampling(Lcmz, dz)

            num_z = np.size(z)
            z2_size = thickness
            dz2 = dz
            z2 = Sampling(z2_size, dz2)
            num_z2 = np.size(z2)
            set_z = Divide(num_z2, num_z)
            if Lcmz > thickness:
                # delta = thickness * np.tan(np.pi/2-theta_fringe) / num_z
                delta = thickness / np.tan(theta_fringe) / num_z2
                # delta = Lcmxx / num_z
            else:
                delta = Lcmx / num_z
            # layer = np.zeros((np.size(wavelength_recording),num_z))
            layer = []
            textures = []
            for a in range(num_z):
                for b in range(np.size(wavelength_recording)):
                    layer = np.append([layer], [n_m_array[b] * np.cos(2 * np.pi * (xx + sign_fringe * a * delta) / (x_size_array[b]))])
                    # layer[b,:] = n_m*np.cos(2*np.pi*(x+sign_fringe*a*delta)/(x_size_array[b]))
                layer = layer.reshape(np.size(wavelength_recording), sampling_x)
                if np.size(wavelength_recording) == 1:
                    textures = np.append(textures, layer + n)
                else:
                    textures = np.append(textures, [np.sum(layer, axis=0) + n])
                layer = []
            textures_check = textures.reshape(num_z, sampling_x)
            textures2 = np.tile(textures, (1, set_z[0]))
            for i in range(set_z[1]):
                textures2 = np.append(textures2, textures_check[i, :])
            # if set_z[1] == 0: # 추가 안해도 될거 같은데
            # T_array = []
            # R_array = []

            # theta0 = Refracted_angle(n1, n, i * interval_angle + start_angle)
            obj = grcwa.obj(nn, [Lcmxx[0], 0], [0, 1 * nm], freq, theta0, -angle_delta, verbose=0)  # ??어째서??
            obj.Add_LayerUniform(0, n1 * n1)
            if set_z[1] == 0:
                for i in range(set_z[0] * num_z):
                    obj.Add_LayerGrid(dz, sampling_x, 1)
            else:
                for ii in range(set_z[0]):  # set[0]*numz + set[1] /dz 두께 만큼만 쌓으면 되네
                    for iii in range(num_z):
                        obj.Add_LayerGrid(dz, sampling_x, 1)
                for iiii in range(set_z[1]):
                    obj.Add_LayerGrid(dz, sampling_x, 1)
                # if T_or_R == 1:
            obj.Add_LayerUniform(0, n2 * n2)  # 반사형 추가하면 큰 일 확인
            obj.Init_Setup()
            if set_z[1] == 0:
                obj.GridLayer_geteps(textures * textures)
            else:
                obj.GridLayer_geteps(textures2 * textures2)
            obj.MakeExcitationPlanewave(planewave['p_amp'], planewave['p_phase'], planewave['s_amp'],
                                        planewave['s_phase'], order=0)  # reference order??
            R, T = obj.RT_Solve(normalize=1, byorder=1)  #

    order_array = obj.G
    real_nn = obj.nG
    order = np.zeros([real_nn])
    for i in range(real_nn):
        order[i] = order_array[i, 0]
    diffraction_order_check = np.where(order == diff_order)
    diffraction_order = diffraction_order_check[0]
    if T_or_R == 1:
        return np.abs(T[diffraction_order[0]])
        # return 1
    else:
        return np.abs(R[diffraction_order[0]])